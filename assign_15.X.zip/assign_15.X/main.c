/*
 * File:   main.c
 * Author: monis
 *
 * Created on 16 January, 2024, 4:01 PM
 */


#include <xc.h>
#include"ssd.h"

void main(void) {
    init_ssd_display();
    unsigned char ssd[4];
    static unsigned char digit[] = {ZERO, ONE, TWO, THREE, FOUR, FIVE, SIX, SEVEN, EIGHT, NINE, BLANK, BLANK};
    char i = 0, j = 1, k = 2, l = 3;
    unsigned int delay = 0;
    while (1) {
        if (delay++ == 100) {
            delay = 0;
            i++;
            k++;
            j++;
            l++;
            i=i%12;
            j=j%12;
            k=k%12;
            l=l%12;
        }
        ssd[0] = digit[i];
        ssd[1] = digit[j];
        ssd[2] = digit[k];
        ssd[3] = digit[l];
        ssd_display(ssd);

        

    }
    return;
}
