/*
 * File:   main.c
 * Author: monis
 *
 * Created on 8 January, 2024, 5:35 PM
 */

#include <xc.h>
#include <pic18f4580.h>
#include "digital_keypad.h"

void init_config(void)
{
    ADCON1 = 0x0F;
    TRISB = 0X00;
    TRISC = TRISC | 0x0F;
    PORTB = 0x00;
}

void glow_on_press(unsigned char key);

void main(void)
{
    init_config();
    unsigned char key_pad,key_copy = 0x0f;
    int flag = 0;
    int flag1 = 0;
    int flag2 = 0;
    while (1)
    {
        key_pad = read_digital_keypad(LEVEL);
        if(key_pad != ALL_RELEASED)
        {
            PORTB = 0x00;
            key_copy = key_pad;
        }
        glow_on_press(key_copy);
    }
}

void glow_on_press(unsigned char key)
{
    static int flag = 0;
    static int flag1 = 0;
    static int flag2 = 0;
    static unsigned long int delay = 10000;
    if (delay++ == 10000)
    {
        delay = 0;
        if (key == SWITCH1)
        {
            if (flag >= 1 && flag <= 8)
            {
                PORTB = (PORTB << 1) | 0x01;
            }
            else if (flag >= 9 && flag <= 16)
            {
                PORTB = PORTB << 1;
            }
            else if (flag >= 17 && flag <= 24)
            {
                PORTB = (PORTB >> 1) | 0x80;
            }
            else if (flag >= 25 && flag <= 32)
            {
                PORTB = PORTB >> 1;
            }
            else
            {
                flag = 0;
            }
            flag++;
        }
        else if (key == SWITCH2)
        {
            if (flag1 >= 1 && flag1 <= 8)
            {
                PORTB = (PORTB << 1) | 0x01;
            }
            else if (flag1 >= 9 && flag1 <= 16)
            {
                PORTB = PORTB >> 1;
            }
            else
            {
                flag1 = 0;
            }
            flag1++;
        }
        else if (key == SWITCH3)
        {
            if (flag2 == 0)
            {
                flag2 = 1;
                PORTB = 0xAA;
            }
            else
            {
                flag2 = 0;
                PORTB = 0x55;
            }
        }
        else if (key == SWITCH4)
        {
            if (flag2 == 0)
            {
                flag2 = 1;
                PORTB = 0xF0;
            }
            else
            {
                flag2 = 0;
                PORTB = 0x0F;
            }
        }
        else
        {
            PORTB = 0x00;
        }
    }
}