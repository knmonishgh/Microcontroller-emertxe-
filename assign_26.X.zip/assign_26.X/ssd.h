/* 
 * File:   ssd.h
 * Author: monis
 *
 * Created on 9 January, 2024, 4:47 PM
 */

#ifndef SSD_H
#define	SSD_H

#ifdef	__cplusplus
extern "C" {
#endif




#ifdef	__cplusplus
}
#endif

#endif	/* SSD_H */

void init_ssd_display(void);

void ssd_display(unsigned char *ssd);

#define SSD_DATA_PORT PORTD

#define SSD_CNT_PORT PORTA

#define ONE 0x21

#define TWO 0xCB

#define THREE 0x6B

#define FOUR 0x2D

#define FIVE 0x6E

#define SIX 0xEE

#define SEVEN 0x23

#define EIGHT 0xEF

#define NINE 0x2F

#define ZERO 0xE7

