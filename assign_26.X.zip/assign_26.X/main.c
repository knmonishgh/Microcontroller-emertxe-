/*
 * File:   main.c
 * Author: monis
 *
 * Created on 16 January, 2024, 4:37 PM
 */


#include <xc.h>
#include"ssd.h"
#include"digital_keypad.h"
#include"EEPROM.h"

void up_count_on_press(char flag);
char count = 0;

void main(void) {
    init_ssd_display();
    init_digital_keypad();
    count = (read_internal_eeprom(0x03)*1000 + read_internal_eeprom(0x02)*100 + read_internal_eeprom(0x01)*10 + read_internal_eeprom(0x00));
    unsigned char key;
    char flag = 0;
    char reset = 0;
    char longpress = 0;
    while (1) {
        key = read_digital_keypad(LEVEL);
        flag = 0;
        if (key == SWITCH1 && reset != 2) {
            reset = 1;
            longpress++;
            if (longpress > 100) {
                flag = 2;
                reset = 2;
            }
        } else if (key == ALL_RELEASED && reset == 1) {
            longpress = 0;
            reset = 0;
            flag = 1;
        } else if (key == ALL_RELEASED) {
            reset = 0;
            longpress = 0;
        }
        if(key == SWITCH2)
        {
            flag = 3;
        }
        up_count_on_press(flag);
    }
    return;
}

void up_count_on_press(char flag) {
    static unsigned char digit[] = {ZERO, ONE, TWO, THREE, FOUR, FIVE, SIX, SEVEN, EIGHT, NINE};
    unsigned char ssd[4];
    
    if (flag == 1) {
        count++;
    } else if (flag == 2) {
        count = 0;
    } else if (flag == 3) {
        write_internal_eeprom(0x00, count % 10);
        write_internal_eeprom(0x01, (count / 10) % 10);
        write_internal_eeprom(0x02, (count / 100) % 10);
        write_internal_eeprom(0x03, count / 1000);
    }
    ssd[3] = digit[count % 10];
    ssd[2] = digit[(count / 10) % 10];
    ssd[1] = digit[(count / 100) % 10];
    ssd[0] = digit[count / 1000];
    ssd_display(ssd);
}
