
#include <xc.h>
#include "ssd.h"

void init_ssd_display(void)
{
    TRISD = 0x00;
    TRISA = TRISA & 0xF0;
    PORTA = PORTA & 0xF0;
    
}

void ssd_display(unsigned char *SSD)
{
    for(unsigned char i=0;i<4;i++)
    {
        SSD_DATA_PORT = SSD[i];
        SSD_CNT_PORT = (SSD_CNT_PORT & 0xF0) | 0x01<<i;
        for(unsigned int wait = 1000;wait--;);
    }
}
