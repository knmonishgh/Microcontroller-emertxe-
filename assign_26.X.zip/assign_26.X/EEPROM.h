/* 
 * File:   EEPROM.h
 * Author: monis
 *
 * Created on 12 January, 2024, 4:37 PM
 */

#ifndef EEPROM_H
#define	EEPROM_H

#ifdef	__cplusplus
extern "C" {
#endif




#ifdef	__cplusplus
}
#endif

#endif	/* EEPROM_H */

void write_internal_eeprom(unsigned char addr, unsigned char data);

unsigned char read_internal_eeprom(unsigned char addr);