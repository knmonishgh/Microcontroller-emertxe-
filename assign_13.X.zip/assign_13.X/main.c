/*
 * File:   main.c
 * Author: monis
 *
 * Created on 16 January, 2024, 4:37 PM
 */


#include <xc.h>
#include"ssd.h"
#include"digital_keypad.h"

void up_count_on_press(char flag);

void main(void) {
    init_ssd_display();
    init_digital_keypad();
    unsigned char key;
    char flag = 0;
    char reset = 0;
    char longpress = 0;
    while (1) {
        key = read_digital_keypad(LEVEL);
        flag = 0;
        if (key == SWITCH1 && reset != 2 ) {
            reset = 1;
            longpress++;
            if (longpress > 100) {
                flag = 2;
                reset = 2;
            }
        } else if (key == ALL_RELEASED && reset == 1) {
            longpress = 0;
            reset = 0;
            flag = 1;
        } else if (key == ALL_RELEASED) {
            reset = 0;
            longpress = 0;
        }
        up_count_on_press(flag);
    }
    return;
}

void up_count_on_press(char flag) {
    static unsigned char digit[] = {ZERO, ONE, TWO, THREE, FOUR, FIVE, SIX, SEVEN, EIGHT, NINE};
    unsigned char ssd[4];
    static char count = 0;
    if (flag == 1) {
        count++;
    } else if (flag == 2) {
        count = 0;
    }
    ssd[3] = digit[count%10];
    ssd[2] = digit[(count/10)%10];
    ssd[1] = digit[(count/100)%10];
    ssd[0] = digit[count/1000];
    ssd_display(ssd);
}
