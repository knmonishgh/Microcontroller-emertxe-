/*
 * File:   main.c
 * Author: monis
 *
 * Created on 11 January, 2024, 3:41 PM
 */


#include <xc.h>

void config()
{
    TRISB = 0X00;
    PORTB = 0X00;
}
 
void main(void) {
    config();
    unsigned long int delay = 100000;
    int flag=0;
    while(1)
    {
        if(delay++ == 100000)
        {
            delay = 0;
            if(flag>=1&&flag<=8)
            {
                PORTB = (PORTB << 1) | 0x01 ; 
            }
            else if(flag>=9 && flag<=16)
            {
                PORTB = PORTB << 1;
            }
            else if(flag>=17 && flag<=24)
            {
                PORTB = (PORTB >> 1 ) | 0x80;
            }
            else if(flag>=25 && flag<=32)
            {
                PORTB = PORTB >> 1;
            }
            else
            {
                flag = 0;
            }
            flag++;
        }
    }
    return;
}
